---
title: "Business Technology - Tech Stack Details"
description: "A list of tools and applications used internally at GitLab and how to access them."
---

This is a listing of the applications we use at GitLab. If you're looking for the technology used to deliver GitLab.com, please visit the [Production Architecture page](/handbook/engineering/infrastructure-platforms/production/architecture/).

## Tech stack related processes

### Update tech stack information

Please visit our [Tech Stack main page](/handbook/business-technology/tech-stack-applications/#tech-stack-updates) for instructions on how to request updates to the Tech Stack information.

### Request Access

If you need to request access for a tool, please refer to and follow the [Access Request process](/handbook/eta/corporate-it/end-user-services/access-requests/access-requests/).

## Tech Stack Applications

For the list of applications, their owners, and how to request updates, see [Tech Stack Applications](/handbook/business-technology/tech-stack-applications/).
