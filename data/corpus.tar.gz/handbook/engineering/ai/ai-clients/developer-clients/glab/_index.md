---
title: glab
description: "The glab functional team owns and maintains glab, the GitLab CLI, bringing GitLab directly into developers' terminals and workflows."
---

## Overview

The glab functional team is part of the [Developer Clients group](/handbook/engineering/ai/ai-clients/developer-clients/) within the [AI Clients stage](/handbook/engineering/ai/ai-clients/).

For shared planning processes, workflow boards, useful links, and dashboards, see the [Developer Clients group page](/handbook/engineering/ai/ai-clients/developer-clients/).

## Public Docs

[GitLab CLI documentation](https://docs.gitlab.com/cli/)

---

## 👨‍💻 Team Members

{{< group-by-slugs aelhusseiny jay_mccure >}}

### Stable Counterparts

The following people are [stable counterparts](/handbook/leadership/#stable-counterparts) of the glab team:

{{< group-by-slugs james.casey ychen16 lyspin >}}

---

## 💬 Slack

- **Team channel:** [#f_cli](https://gitlab.enterprise.slack.com/archives/C0380FL4K1R)
- **Public stage channel:** [#s_ai-clients-questions](https://gitlab.enterprise.slack.com/archives/C058YCHP17C)

---

## 💻 Scope

The glab team is responsible for glab, the GitLab CLI, which lets developers manage issues, merge requests, CI/CD pipelines, and more directly from their terminal.

1. **GitLab CLI (glab)**
   - [Repo](https://gitlab.com/gitlab-org/cli)
   - [Docs](https://docs.gitlab.com/cli/)
   - Slack Channel: [#f_cli](https://gitlab.enterprise.slack.com/archives/C0380FL4K1R)

### Issues' Labels

Check [AI Clients labeling guidance](/handbook/engineering/ai/ai-clients/#-how-we-label-issues-and-merge-requests)

---

## 🔗 Useful Links

- [glab issues](https://gitlab.com/gitlab-org/cli/-/issues)
- [Weekly Sync Meeting Agenda](https://docs.google.com/document/d/1UJg-Prf5qGjiGImvaYl5HNjMcJddoeE4u33Ri6SxQ6g)
