---
title: Operating Model for Growth Stage
description: "The operating rhythm for the Growth team: one team, one roadmap, and a weekly reporting cadence."
---

## Operating Rhythm

Growth is one team with one roadmap, focused on Self-Serve (Web Direct) First Orders across GitLab.com and self-managed. The roadmap ranks customer problems by how directly each one drives a first order. Instead of maintaining traditional group boundaries, Product Management, UX, and Engineering resources are flexibly assigned to the highest-ranked work using an agile kanban approach.

## Weekly Cadence

**Wednesday 06:00 UTC**

The triage bot automatically creates status update threads in issues marked with `~"workflow::in dev"`, `~"workflow::in review"`, and `~"workflow::verification"`.

Assignees are expected to provide updates using the bot's comment template and  include demo links if available. All demos should be recorded and uploaded to the [Growth weekly demo playlist](https://www.youtube.com/playlist?list=PL05JrBw4t0KrwPNlpnpqeXIlIjOy_ifFl) as unlisted videos for team reference with a prefix of `[Date]: Theme/title`

**Thursday 20:00 UTC (EOD)**

DRI: Product Manager (gathers input), Engineering Manager and UX (contribute updates and demos)

1. Post in `#s_growth` with key wins for the week, demos and successive priorities
2. The status of the Growth 12-month roadmap is updated in the designated internal doc.

**Friday 20:00 UTC (EOD)**

PMs publish Growth Weekly Report with key themes and priorities, issues delivered, work in progress, blocked issues

**Friday 18:00 UTC (CXO Meeting)**

1. Executive summary is prepared with Web Direct first-order pacing, PLG metrics, and operational priorities
2. Once the CXO meeting is concluded, CXO feedback and action items are posted in `#s_growth`
