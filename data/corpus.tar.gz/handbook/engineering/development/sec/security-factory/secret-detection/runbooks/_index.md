---
title: "Secret Detection Runbooks"
---

## Overview

This page lists runbooks used by the Secret Detection team for monitoring, mitigating and responding to an incident.

## Runbooks

* Secret Push Protection feature
  * [Monitoring](secret-push-protection-monitoring)
  * [Troubleshooting](secret-push-protection-troubleshooting)
  * [Performance Testing](secret-push-protection-performance-testing)
* Secret Detection Service
  * [General FAQs](secret-detection-svc-faqs)
  * [Monitoring](secret-detection-svc-monitoring)
  * _Troubleshooting (TBA, once we complete [#494910](https://gitlab.com/gitlab-org/gitlab/-/issues/494910) and [#499249](https://gitlab.com/gitlab-org/gitlab/-/issues/499249))_
* Secret Validity Check
  * [General FAQs](secret-detection-validity-check-faqs)
  * [Monitoring](secret-detection-validity-check-monitoring)
  * External Token Verification
    * [Troubleshooting](secret-detection-validity-check-troubleshooting)
  * [Adding a vendor (development process)](../validity-check-development-process)
