---
title: Analytics Instrumentation agents and flows
description: "GitLab Duo Agent Platform agents and flows that plan, implement, and review internal events instrumentation"
---

The Analytics Instrumentation group maintains these GitLab Duo Agent Platform agents and flows for internal events instrumentation.
You run agents in chat.
A flow runs the same instructions as its agent: you trigger it from an issue or merge request, and it posts its results there.

Definitions for all agents and flows are in the [analytics-instrumentation agents and flows project](https://gitlab.com/components/agents-and-flows/analytics-instrumentation).

## Agents

### Instrumentation Planner Agent

- **Catalog**: [Planner Agent](https://gitlab.com/groups/gitlab-org/-/automate/agents/1012274)
- **Definition**: [instrumentation_planner_agent.yml](https://gitlab.com/components/agents-and-flows/analytics-instrumentation/-/blob/main/agents/instrumentation_planner_agent.yml)
- **Purpose**: Turns a tracking idea into an implementation-ready tracking requirements issue, or adds research to an existing issue.
- **Invocation**: Chat.
- **Modes**:
  - **New idea**: free-form description of what to track.
  - **Enrich existing issue**: an issue reference (`#1234` or a URL).
  - **URL and interaction list**: a GitLab page URL and a list of UI interactions to track.
- **Output**:
  - New idea and URL modes: an issue that follows the [Analytics Instrumentation Agent Issue template](https://gitlab.com/gitlab-org/gitlab/-/blob/master/.gitlab/issue_templates/Analytics%20Instrumentation%20Agent%20Issue.md), titled `Tracking Requirements: <action> <target> <where>`, with proposed labels `analytics instrumentation`, `Category:<category>`, and `group::<group>`.
  - Enrich mode: a comment headed `## 🔍 Tracking Requirements Research (auto-generated)`. The issue description is not edited.

### Instrumentation Implementation Agent

- **Catalog**: [Implementation agent](https://gitlab.com/groups/gitlab-org/-/automate/agents/1012273)
- **Definition**: [instrumentation_implementation_agent.yml](https://gitlab.com/components/agents-and-flows/analytics-instrumentation/-/blob/main/agents/instrumentation_implementation_agent.yml)
- **Purpose**: Creates event and metric definitions, instrumentation code, and specs, then opens or updates a merge request.
- **Invocation**: Chat, or on an analytics instrumentation issue.
- **Modes**:
  - **Issue-driven**: posts an Instrumentation Plan on the issue and waits for confirmation before implementing.
  - **Prompt-driven**: asks clarifying questions, then either opens the merge request directly or creates an issue and continues in issue-driven mode.
- **Output**:
  - A new or updated merge request.
  - Issue-driven mode only: status notes on the issue, such as `⏳ Starting implementation`, `Instrumentation Plan — Amendment`, `✅ MR opened`, `🔗 introduced_by_url updated`, or `❌ Implementation failed`.

### Instrumentation Reviewer Agent

- **Catalog**: [Reviewer agent](https://gitlab.com/groups/gitlab-org/-/automate/agents/1012275)
- **Definition**: [instrumentation_reviewer_agent.yml](https://gitlab.com/components/agents-and-flows/analytics-instrumentation/-/blob/main/agents/instrumentation_reviewer_agent.yml)
- **Purpose**: Reviews the analytics instrumentation files in a merge request: event and metric definitions, tracking calls, tests, and data privacy.
- **Invocation**: Chat, with a merge request reference.
- **Scope**: Analytics instrumentation files only, matched by path or by tracking calls in the file content. The full list is in the definition file.
- **Output**:
  - A summary note with the status `❌ Changes Required`, `⚠️ Needs Improvement`, or `✅ Approved`.
  - One inline diff note per finding, prefixed `[issue]`, `[suggestion]`, or `[nitpick]`.
  - If no files are in scope: `✅ No analytics instrumentation changes detected — nothing to review`.

## Flows

### Instrumentation Implementation Flow

- **Catalog**: [Implementation flow](https://gitlab.com/groups/gitlab-org/-/automate/flows/1009306)
- **Definition**: [instrumentation_implementation_flow.yml](https://gitlab.com/components/agents-and-flows/analytics-instrumentation/-/blob/main/flows/instrumentation_implementation_flow.yml)
- **Runs**: [Instrumentation Implementation Agent](#instrumentation-implementation-agent), in issue-driven mode.
- **Triggers**: Mention `@ai-instrumentation-agent-gitlab-org`, or add that user as an assignee or reviewer.
- **Output**: The Instrumentation Plan, status notes, and merge request link, posted on the issue.

### Instrumentation Reviewer Flow

- **Catalog**: [Reviewer flow](https://gitlab.com/groups/gitlab-org/-/automate/flows/1009102)
- **Definition**: [instrumentation_reviewer_flow.yml](https://gitlab.com/components/agents-and-flows/analytics-instrumentation/-/blob/main/flows/instrumentation_reviewer_flow.yml)
- **Runs**: [Instrumentation Reviewer Agent](#instrumentation-reviewer-agent).
- **Triggers**:
  - Ready merge requests: starts automatically when the merge request is ready for review.
  - Draft merge requests: mention `@ai-instrumentation-review-gitlab-org`, or run `/request_review @ai-instrumentation-review-gitlab-org`.
- **Output**: The same summary note and inline diff notes as the agent, posted on the merge request.

## External data sources

Before doing any work, all agents and flows fetch these sources from each source project's default branch:

| Source | Used for |
|--------|----------|
| [GitLab `VERSION`](https://gitlab.com/gitlab-org/gitlab/-/blob/master/VERSION#L1) | `milestone` |
| [`stages.yml`](https://gitlab.com/gitlab-com/www-gitlab-com/blob/master/data/stages.yml) | Valid `product_group` values |
| [`feature_categories.yml`](https://gitlab.com/gitlab-org/gitlab/-/blob/master/config/feature_categories.yml) | Valid `product_categories` values |

## Related

- Capabilities, how each agent works, and example prompts: [analytics-instrumentation project README](https://gitlab.com/components/agents-and-flows/analytics-instrumentation)
- [Internal Events quick start guide](https://docs.gitlab.com/development/internal_analytics/internal_event_instrumentation/quick_start/)
- Questions and feedback: open an issue in the [analytics-instrumentation agents and flows project](https://gitlab.com/components/agents-and-flows/analytics-instrumentation) or ask in [#g_analyze_analytics_instrumentation](https://gitlab.slack.com/archives/CL3A7GFPF)
