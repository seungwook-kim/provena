---
title: "Development Tooling team"
description: "The Development Tooling team enables modular service development at GitLab through Theseus"
---

## Mission

- Enable modular service development at GitLab through the [Theseus](https://theseus.gitlab.net/) platform.
- Enable team members and the wider community to contribute efficiently to our tools and products.
- Measure what matters: improvements in developer experience, efficiency, and toil reduction, using both quantitative and qualitative metrics.

## Vision

Shipping a new modular service at GitLab takes weeks before a team writes any business logic. Our vision is to make that hours, as part of the [Theseus vision](https://theseus.gitlab.net/overview/vision/): a paved path from a developer's laptop to a deployed, operable service.

- LabKit gives every service the same logging, metrics, and tracing from the first commit.
- Caproni gives every contributor a production-like development environment, locally and in CI.

## Areas of responsibilities

The team is focused on [Theseus](https://theseus.gitlab.net/) and delivers two of its components, LabKit and Caproni.

```mermaid
flowchart LR
    DT[Development Tooling] --> Theseus[Theseus]
    click Theseus "https://theseus.gitlab.net/"
    Theseus --> Caproni[Caproni]
    click Caproni "https://gitlab.com/gitlab-org/caproni"
    Theseus --> labkit[LabKit]
    click labkit "https://handbook.gitlab.com/handbook/engineering/infrastructure-platforms/developer-experience/labkit/"

    DT --> CanonicalTooling[gitlab-org/gitlab Tooling]
    CanonicalTooling --> StaticAnalysis[Static Analysis]

    DT --> AuxTooling[Auxiliary Tooling<br><small>Useful tools for GitLab.com.</small>]
    AuxTooling --> civiz[Pipeline Visualizer]

    click civiz "https://gitlab.com/gitlab-org/quality/engineering-productivity/pipeline-visualizer"
```

### GitLab Development Kit (GDK)

We are no longer focusing on the [GitLab Development Kit](https://gitlab.com/gitlab-org/gitlab-development-kit/). Caproni is now [GitLab's strategic development platform](https://theseus.gitlab.net/changelog/2026-09-03-caproni-strategic-development-platform/) and will replace GDK over the coming quarters for all GitLab contributors, including team members, [Co-Create Program](https://about.gitlab.com/community/co-create/) customers, and community contributors.

- GDK will largely be limited to critical bug fixes.
- New services that need a production-like development environment should use Caproni today.
- Teams building on GDK should plan their migration to Caproni and read the [Caproni documentation](https://gitlab-org.gitlab.io/caproni/).

Questions about Caproni go to the [`#proj_caproni`](https://gitlab.enterprise.slack.com/archives/C0ACPMUMETZ) Slack channel or the [Caproni issue tracker](https://gitlab.com/gitlab-org/caproni).

## Team Structure

{{< team-by-manager-slug "skodali3" >}}

## Roadmap

As part of continuous roadmapping, we'll review our roadmap quarterly, updating it as we validate or refine our approach and reflect new priorities.

### Now

**Focus:** Enable adoption of Theseus through Caproni and LabKit

We track Caproni adoption in the [Caproni dashboard](https://dashboards.gitlab.net/d/development-tooling-caproni/development-tooling3a-caproni) (internal).

### Next

TBD

### Later

TBD

### Keeping The Lights On (KTLO)

In addition to planned work, our team will also be responsible for ongoing maintenance and support that impacts shared tooling functionality and infrastructure, such as dependency upgrades, security vulnerabilities, critical bug fixes, etc.

## Working with us

For problems, feature requests, enhancements: Please **[create an issue](https://gitlab.com/gitlab-org/quality/request-for-help/-/issues/new?description_template=developer_experience_request)** in our [RFH repo](https://gitlab.com/gitlab-org/quality/request-for-help#developer-experience---request-for-help). Or you can Engage us in `#g_development_tooling`.

For individual questions, please mention team members directly on GitLab.com or reach out to the team through our Slack channels.

### Communication

| Description            | Link                                                                                                                                         |
| ---------------------- | -------------------------------------------------------------------------------------------------------------------------------------------- |
| **GitLab Team Handle** | [`@gl-dx/development-tooling`](https://gitlab.com/gl-dx/development-tooling)                                                                     |
| **Slack Channel**      | [`#g_development_tooling`](https://gitlab.enterprise.slack.com/archives/C07UW7F3FL2)                                                           |
| **Team Issue Board**   | [Team Issue Board](https://gitlab.com/groups/gitlab-org/-/boards/8974136?label_name%5B%5D=group%3A%3Adevelopment+tooling&iteration_id=Current) |
| **Issue Tracker**      | [`gitlab-org/dx/tooling/team`](https://gitlab.com/gitlab-org/quality/tooling/team/-/issues/)                                                 |

## How we work

We're geographically distributed across AMER & EMEA regions and work asynchronously by default.

### Meetings

As a whole team, we meet synchronously once a week to discuss ongoing topics. To facilitate a productive discussion, topics should be entered into the agenda by the beginning of the week.

### Project Management

We follow project management process for [Infrastructure Platforms department](/handbook/engineering/infrastructure-platforms/project-management/).

For more information on current projects, refer to our [parent epic](https://gitlab.com/groups/gitlab-org/quality/-/epics/114).
