---
title: "API Platform team"
description: "The API Platform team enables GitLab contributors to efficiently build and maintain APIs that are discoverable and stable for customers"
---

## Team scope

The API Platform team owns GitLab's API architectures, standards, and platform-wide capabilities. Contact us for cross-cutting API concerns, design patterns, or foundational improvements. For feature-specific endpoints or functionality, [reach out to the team that owns that feature area](/handbook/product/categories/features/).

Please direct all API Platform team requests to our [request for help process](/handbook/engineering/infrastructure-platforms/developer-experience/api/#working-with-us). Alternatively, GitLab team members are welcome to attend our [office hours](https://docs.google.com/document/d/1MuN71IU-Y_EhMRKouiANMHdz7yG5znhO4lhT0Lyfdpk/edit?tab=t.0#heading=h.k0ifed17isg9) held at **11am UK time** on the last Tuesday of the month.

## Mission

The API Platform team owns GitLab's REST and GraphQL APIs as a product, and enables API-first development across GitLab. As part of Developer Experience, the API Platform team provides tooling, processes, and practices to help contributors efficiently build and maintain APIs for customers.

As a newly formed team in FY26-Q2, we're building our expertise in `#f_rest_api` and `#f_graphql` by working on platform-level projects and working closely with existing domain experts. Over time, the API Platform team's expertise will evolve into driving steering committee for API standards and decisions across GitLab.

## Vision

The API Platform team transforms GitLab into an API-first platform where APIs are a core part of how customers and agents integrate with GitLab. We achieve this through the 4Ds framework, where each investment reinforces the others in a continuous improvement cycle:

- **Documentation**
  - Automated OpenAPI specifications for REST API endpoints
  - Interactive documentation and practical workflow examples

- **Deprecations**
  - Clear lifecycle progression from experimental to GA
  - Predictable deprecation timelines that never break customer integrations

- **Data-driven**
  - Collect aggregated product usage metrics to guide API improvements and investment decisions
  - Improved observability for GraphQL API

- **Development**
  - Contributors ship APIs by default using automated tooling and paved paths
  - Architecture that facilitates consistency across REST/GraphQL APIs

These initiatives create a flywheel effect: better documentation drives adoption, deprecation management builds trust, data insights guide improvements, and development tools make it all sustainable.

As the owners of APIs at GitLab, the API Platform team provides the stewardship and platform-level investment needed to transform our APIs into a product customers can rely on. Through scalable automation and tooling rather than one-off fixes, we achieve economies of scale that benefit both contributors and customers.

## Team structure

The API Platform team consists of 4 engineers (2 Staff, 2 Intermediate) and 1 Engineering Manager.

### Members

{{< team-by-manager-slug manager="pjphillips" team="Developer Experience:API(.*)" >}}

## Roadmap

As a lean team, we balance high confidence in our "Now" commitments while keeping "Next" and "Later" commitments directionally aligned and flexible. For more information on technical roadmap, refer to [Infrastructure Platforms roadmap](https://infra-roadmap-c6d14f.gitlab.io/).

### Now

**Focus: Documentation and Development - One API model for modular features** (FY27-Q3)

- [REST API Docs Production Readiness and Public Beta Launch](https://gitlab.com/groups/gitlab-org/quality/-/work_items/402)
- [REST API Docs GA: retire the Markdown reference](https://gitlab.com/groups/gitlab-org/quality/-/work_items/471)
- [OpenAPI Annotations - REST Endpoint Tier](https://gitlab.com/groups/gitlab-org/quality/-/work_items/366)
- [Establish one API definition model for all GitLab modular features](https://gitlab.com/groups/gitlab-org/quality/-/work_items/465)
- [Ship an API spec with every new modular feature by default](https://gitlab.com/groups/gitlab-org/quality/-/work_items/429)
- [Make every modular feature API state how to authenticate against it](https://gitlab.com/groups/gitlab-org/quality/-/work_items/466)

For the full list of current, ready, and completed work, refer to our [parent epic](https://gitlab.com/groups/gitlab-org/quality/-/work_items/200).

### Next

**Focus: Deprecations and Data-driven - GraphQL quality and API visibility per team** (FY27-Q4)

- **GraphQL schema lifecycle**: remove deprecated fields on schedule ahead of GitLab 20.0, graduate experiments, and block breaking schema changes in CI.
- **GraphQL N+1 and query cost**: make efficient data loading the default and catch N+1 queries before merge.
- **GraphQL schema consistency**: lint new schema additions in CI and define one error model.
- **API scorecard per team**: one view per stage group of the quality of the REST and GraphQL APIs it owns.
- [Add GraphQL support to Scalar, upstream](https://gitlab.com/groups/gitlab-org/quality/-/work_items/439)

### Later

**Focus: Development - Safe, consistent APIs across GitLab components** (FY28 and beyond)

- [OpenAPI Annotations - REST Parameters](https://gitlab.com/groups/gitlab-org/quality/-/work_items/474)
- [Block breaking API changes in CI across all GitLab components](https://gitlab.com/groups/gitlab-org/quality/-/work_items/432)
- [Provide a contract testing framework for GitLab APIs](https://gitlab.com/groups/gitlab-org/quality/-/work_items/434)
- [Reduce reactive API security work with pre-Rails request validation](https://gitlab.com/groups/gitlab-org/quality/-/work_items/430)
- [Own and deliver the shared GitLab protobuf monorepo](https://gitlab.com/groups/gitlab-org/quality/-/work_items/431)
- [Upgrade GitLab monolith Rest API framework (Grape) from 3.2 to 4.0](https://gitlab.com/groups/gitlab-org/quality/-/work_items/473)
- [Improve API-first development adoption](https://gitlab.com/groups/gitlab-org/quality/-/work_items/383)

### Recently delivered

Since the last roadmap update in May 2026, we delivered:

- [Support all Grape keywords](https://gitlab.com/groups/gitlab-org/quality/-/work_items/321)
- [REST API Docs Internal Beta Launch](https://gitlab.com/groups/gitlab-org/quality/-/work_items/369)
- [Burn down Redocly OpenAPI 3.0 specification errors and warnings](https://gitlab.com/groups/gitlab-org/quality/-/work_items/363)
- [Upgrade Grape from 2.0.0 to 2.4.x](https://gitlab.com/groups/gitlab-org/quality/-/work_items/385)
- [Improve detection of canary-breaking GraphQL frontend and backend changes](https://gitlab.com/groups/gitlab-org/quality/-/work_items/436)
- [Prevent REST Entity Exposure Growth](https://gitlab.com/groups/gitlab-org/-/work_items/20829)
- [Render multiple API specs in the interactive reference](https://gitlab.com/groups/gitlab-org/quality/-/work_items/433)
- [Upgrade GitLab monolith Rest API framework (Grape) from 2.4.0 to 3.2.1](https://gitlab.com/groups/gitlab-org/quality/-/work_items/438)
- [Publish Orbit and Artifact Registry REST APIs in the public API reference](https://gitlab.com/groups/gitlab-org/quality/-/work_items/428)

### Keeping The Lights On (KTLO)

In addition to planned work, the API Platform team will also be responsible for ongoing maintenance that impacts shared functionality across API surface areas, such as security vulnerabilities, critical bug fixes, etc.

## Working with us

**During team formation period:**

- For REST API questions: Start in `#f_rest_api` where domain experts can help
- For GraphQL questions: Start in `#f_graphql` where domain experts can help
- For platform-level API improvements: Please **[create an issue](https://gitlab.com/gitlab-org/quality/request-for-help/-/issues/new?issuable_template=api_team_request)** in our [RFH repo](https://gitlab.com/gitlab-org/quality/request-for-help#developer-experience---request-for-help). Or you can Engage us in `#g_api-platform`
- We're not yet requiring reviews by API Platform team until we've built up toward that capability

For individual questions, please mention team members directly on GitLab.com or reach out to the team through our Slack channels.

### Slack Channels

| Channel | Purpose |
| :---: | :--- |
| [#g_api-platform](https://gitlab.enterprise.slack.com/archives/C095E77BLHJ) | Engage directly with API Platform Team |
| [#f_rest_api](https://gitlab.enterprise.slack.com/archives/C08LQBMLXPF) | Engage with domain experts on REST API |
| [#f_graphql](https://gitlab.enterprise.slack.com/archives/C6MLS3XEU) | Engage with domain experts on GraphQL API |

## How we work

The API Platform team is geographically distributed across AMER and EMEA regions and works asynchronously by default.

### Meetings

The API Platform meets synchronously once a week. For more information on sync meeting, refer to [agenda notes](https://docs.google.com/document/d/1GeZ47_EIHVYw1KB4fCn-VUGe-fRNrs5ezTjm2s51YZE/edit?tab=t.0#heading=h.1n5rp8nv4ncb).

### Project Management

The API Platform team follows project management process for [Infrastructure Platforms department](/handbook/engineering/infrastructure-platforms/project-management/).

For more information on current projects, refer to [parent epic](https://gitlab.com/groups/gitlab-org/quality/-/epics/200).
