---
title: "Engineering Productivity team"
---

> ℹ️ Note: This page is deprecated. The team has been restructured as [Development Health](/handbook/engineering/infrastructure-platforms/developer-experience/development-health/) and Development Tooling under the Developer Experience Stage.

Tools and processes that previously belonged to Engineering Productivity are being re-assigned or deprecated. The handbook and GitLab docs will be updated to reflect the new changes.
