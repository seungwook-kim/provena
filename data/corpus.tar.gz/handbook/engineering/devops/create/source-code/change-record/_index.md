---
title: "Create:Change Record Team"
description: The Source Code team focused on the journey tracking changes after code is committed and merged, responsible for the ledger of changes and how people see it.
---

## What we do

Change Record focuses on the journey tracking changes after code is committed and merged. The team is responsible for the ledger of changes and how people see it.

This page is a stub. The scope, ownership and ways of working will be added as the team defines them.

## Team members

{{< team-by-manager-role role="Engineering Manager(.*)Create:Change Record" team="Create:Change Record" >}}

## Stable counterparts

{{< engineering/stable-counterparts manager-role="Engineering Manager(.*)Create:Change Record" role="(Product Manager|Product Designer)(.*)Create:Source Code(,|$)|Director of Engineering(.*), Plan$" >}}

Technical writer: Brendan Lynch (shared with the other Source Code teams).

## Links

- [Create:Source Code teams](/handbook/engineering/devops/create/source-code/)
- [Create:Agentic Preview](/handbook/engineering/devops/create/source-code/agentic-preview/)
- Slack: `#g_create_change-record`
