---
title: "Create:Agentic Preview Team"
description: The Source Code team responsible for the user journeys that lead up to commits, capturing and processing agentic metadata and turning it into a preview a human can check before anything moves forward.
---

## What we do

Agentic Preview is responsible for the user journeys that lead up to commits. The team captures and processes agentic metadata, and turns it into a preview a human can check before anything moves forward.

This page is a stub. The scope, ownership and ways of working will be added as the team defines them.

## Team members

{{< team-by-manager-role role="Engineering Manager(.*)Create:Agentic Preview" team="Create:Agentic Preview" >}}

## Stable counterparts

{{< engineering/stable-counterparts manager-role="Engineering Manager(.*)Create:Agentic Preview" role="(Product Manager|Product Designer)(.*)Create:Source Code(,|$)|Director of Engineering(.*), Plan$" >}}

Technical writer: Brendan Lynch (shared with the other Source Code teams).

## Links

- [Create:Source Code teams](/handbook/engineering/devops/create/source-code/)
- [Create:Change Record](/handbook/engineering/devops/create/source-code/change-record/)
- Slack: `#g_create_agentic-preview`
