---
title: "Create:Source Code teams"
description: The Create:Source Code teams are responsible for both the backend and frontend aspects of the product categories that fall under the Source Code group of the Create stage.
---

Please follow the links below to visit the pages of the engineering teams that make up the Source Code Management group.

The permanent [Agentic Preview team](/handbook/engineering/devops/create/source-code/agentic-preview/) is responsible for the user journeys that lead up to commits, capturing and processing agentic metadata and turning it into a preview a human can check before anything moves forward.

The permanent [Change Record team](/handbook/engineering/devops/create/source-code/change-record/) focuses on the journey tracking changes after code is committed and merged, and is responsible for the ledger of changes and how people see it.

The temporary [Source Code Hardening and Modernization team](/handbook/engineering/devops/create/source-code/hardening-and-modernization/) (2026-09-21 → 2027-09-10) addresses systemic security and frontend problems across Source Code.

The permanent [Repository Services team](/handbook/engineering/devops/create/source-code/repository-services/) owns the repository side of Source Code and builds an access layer on the Gitaly team's primitives.
