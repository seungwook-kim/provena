---
title: Plan:Spec-Driven Development Engineering Team
description: Engineering team page for the Plan:Spec-Driven Development group.
---

## Plan:Spec-Driven Development team

The Plan:Spec-Driven Development team works on
GitLab's [Spec-Driven Development group](/handbook/product/categories/#spec-driven-development-group) in the [Plan stage](/handbook/engineering/devops/plan/).
Its label is ~"group::spec-driven development" and its Slack channel is [#g_spec-driven-development](https://gitlab.slack.com/archives/g_spec-driven-development).

### Vision

Intent-to-Code is the vision for the Spec-Driven Development group. A person states what they want, and GitLab helps turn that into reviewed, working code.

Spec-driven development writes structured specifications before code and treats them as the source of truth for both people and AI. We keep the spec in the work item, so people and agents work from one source of truth for what to build, why, and how. Specs stay alive and change with the feature. The work item holds the intent, the discussion, the decisions, the plan, the status and the linked merge requests. Plan is where work is understood and agreed before code is written.

The workflow has a few steps:

- Refine the description to say what is needed and why.
- Generate a plan that says how.
- Keep a decision log.
- Resolve open questions together.
- Check that the work is ready.
- Show when an agent is working or waiting for input.

Each step can run with a person in the loop or on its own, depending on how much the team trusts the outcome.

People and agents split the work. People set the intent, the acceptance criteria and the guardrails, make the consequential decisions and own the outcome. Agents gather context, refine requirements, draft plans, write code and tests, and review the result against the plan.

This is the entry point to GitLab's Software Factory direction. Instead of people coordinating every change by hand, agents run the delivery loop and people govern it and stay in control of approvals.

### What we work on

The group owns the planning layer on work items that lets a work item be handed to an AI agent. It has no categories of its own in the product categories list.

- Workplan on work items, the plan that says how the work will be done. See the [user docs](https://docs.gitlab.com/user/work_items/workplan/).
- The decision log, a record of decisions on a work item.
- Readiness, which shows whether a work item is ready for an agent to run.
- The flow that hands a ready work item to Duo Developer.

### Design documents

The [design document](/handbook/engineering/architecture/design-documents/spec_driven_development/) describes the Workplan and its supporting features.

- [Workplan](/handbook/engineering/architecture/design-documents/spec_driven_development/workplan/): the widget that stores the plan.
- [Decision log](/handbook/engineering/architecture/design-documents/spec_driven_development/decision_log/): the widget for structured decisions.
- [Readiness](/handbook/engineering/architecture/design-documents/spec_driven_development/readiness/): how ready a work item is for agent execution.
- [Async workplan flow](/handbook/engineering/architecture/design-documents/spec_driven_development/workplan-flow/): background research, planning, and readiness scoring.
- [Human in the loop](/handbook/engineering/architecture/design-documents/spec_driven_development/human-in-the-loop/): clarifying questions, decisions, and resuming the flow.
- [Downstream consumers](/handbook/engineering/architecture/design-documents/spec_driven_development/downstream_consumers/): how Duo Developer uses the plan. Duo Review validation is deferred.
- [Work item to merge request relationship](/handbook/engineering/architecture/design-documents/spec_driven_development/wi_mr_relationship/): the two-way link SDD needs.
- [Testing and feedback](/handbook/engineering/architecture/design-documents/spec_driven_development/#testing-and-feedback): dogfooding and usage measurement.

### Team members

{{< team-by-manager-role role="Engineering Manager(.*)Plan:Spec-Driven Development" team="Spec-Driven Development">}}

### Stable counterparts

{{% engineering/stable-counterparts manager-role="Engineering Manager(.*)Plan:Spec-Driven Development" role="Spec-Driven Development|Security(.*)Plan( |:|,|$)|Principal(.*)Plan$" %}}

Technical Writer is Brendan Lynch.

## How we work

The group shares its Engineering Manager with Plan:Work Items, so the process on the [Work Items team page](/handbook/engineering/devops/plan/work-items/) applies here. The [Plan stage page](/handbook/engineering/devops/plan/) covers the stage-wide workflow.

## Useful links

- [Issues labeled `group::spec-driven development`](https://gitlab.com/groups/gitlab-org/-/issues/?label_name%5B%5D=group%3A%3Aspec-driven%20development)
- [#g_spec-driven-development](https://gitlab.slack.com/archives/g_spec-driven-development) in Slack
- [Plan Stage - Intent-to-Code epic](https://gitlab.com/groups/gitlab-org/-/work_items/21218)
- [Design documents](/handbook/engineering/architecture/design-documents/spec_driven_development/)
- [Group wiki](https://gitlab.com/groups/gitlab-org/plan-stage/sdd/-/wikis/_Home) (internal)
- [Benchmark dashboard project](https://gitlab.com/gitlab-org/plan-stage/sdd/spec-driven-development-evaluation-dashboard) (internal)
