---
title: Plan:Work Items Team
---

## Plan:Work Items Team

The Plan:Work Items team works on GitLab's [Work Items group](/handbook/product/categories/#work-items-group) in the [Plan stage](/handbook/engineering/devops/plan/).
The group renamed from Project Management in the FY27 reorg.

### What we own

The group owns three categories, plus the work items framework they run on (widgets and the GraphQL and REST APIs for work items).

- Team Planning: issues, tasks, labels, milestones, assignees, weights, dates, statuses, time tracking, discussions, internal notes, description templates, quick actions, work item types and settings, and merge request linking. See the [Plan and track docs](https://docs.gitlab.com/topics/plan_and_track/).
- Service Desk: service desk issues, custom email and branding, and customer relations management (CRM). See the [Service Desk docs](https://docs.gitlab.com/user/project/service_desk/).
- Notifications: web and email notifications and to-dos. See the [notifications docs](https://docs.gitlab.com/user/profile/notifications/).

### Team members

{{< team-by-manager-role role="Engineering Manager(.*)Plan:Work Items" team="Plan:Work Items">}}

### Stable counterparts

{{% engineering/stable-counterparts manager-role="Engineering Manager(.*)Plan:Work Items" role="Plan:Work Items|Security(.*)Plan( |:|,|$)|Principal(.*)Plan$" %}}

Technical Writer is Brendan Lynch. For UX questions, @ mention [Nick Brandt](https://gitlab.com/nickbrandt) or [Sunjung Park](https://gitlab.com/sunjungp), the Product Design contacts for the Plan stage.

## How we work

The Plan stage page describes [how we work as a stage](/handbook/engineering/devops/plan/).

For the backend team specifically, we use the standard GitLab
[engineering workflow](/handbook/engineering/workflow/). To get in touch with the Plan:Work Items
team, create an issue in the relevant project
(typically [GitLab](https://gitlab.com/gitlab-org/gitlab)) and add the ~"group::work items" label, along
with any other appropriate labels. Then ping the relevant
Product Manager or Engineering Manager as listed above.

For quick questions, use [#g_work_items](https://gitlab.slack.com/archives/g_work_items) on Slack. [#s_plan](https://gitlab.slack.com/archives/s_plan) is the stage-wide channel and [#s_plan_standup](https://gitlab.slack.com/archives/s_plan_standup) is the async standup.

### Error budget

The [error budget dashboard](https://dashboards.gitlab.net/d/stage-groups-work_items/stage-groups-group-dashboard-plan-work-items) shows how the group is doing against its availability target.

The [Engineering Excellence dashboard](https://gitlab-com.gitlab.io/eng-excellence/?view=ee&scope=stage%3Aplan) (internal, requires sign-in) shows velocity, reliability, correctness, security and efficiency for the Plan stage.

### Capacity planning

#### Estimating effort

When estimating the effort involved in upcoming work, we use the same approach and numerical scale as other groups in the Plan stage.

{{% include "includes/engineering/plan/estimating-effort.md" %}}

#### Weighing bugs

{{% include "includes/engineering/plan/weighing-bugs.md" %}}

#### Refining and organizing feature work

To help drive alignment with our stable counterparts, provide visibility into progress, and breakdown our vision into a series of [MVCs](/handbook/product/product-principles/#the-minimal-valuable-change-mvc), we collaborate with Product and UX during [`~workflow::planning breakdown`](/handbook/product-development/how-we-work/product-development-flow/#description-4) to refine and organize `~type::feature` deliverables into the following structure:

- Feature (Epic) - Contains all the necessary vertical feature slices to default the corresponding feature flag to "on". The feature epic will also serve as the location to generate a corresponding Release Post item MR. The feature epic should be scoped to the [minimal amount of functionality that still provides customer value](/handbook/product/product-principles/#the-minimal-valuable-change-mvc). Additional scope planned for future enhancements should be stored in follow-on epics.
  - Spike (Issue) - If we are unable to accurately estimate the effort necessary to implement the feature, we first conduct a spike
  - UX (Issue) - For larger initiatives, UX creates a separate UX issue that serves as the SSOT for design goals, design drafts, design conversation and critique, and the chosen design direction that will be implemented. [Learn more about UX issues](/handbook/upstream-studios/product-design/ux-themes/).
  - Vertical Feature Slice (Issue) - A subset of the feature that can be completed within a single milestone, tested, and verified within the `plan-stage` group on production.
    - Engineering Tasks (Task - *Optional*) - One or more engineering tasks that need to be completed in order to deliver the vertical feature slice. The scope of a task should generally correlate to a single MR.

During the `~workflow::planning breakdown` phase, all issues need to be weighted so we can efficiently and effectively collaborate with Product and UX on "right sizing" the feature epic. It's advisable that all issues are connected to a parent epic that describes the broader set of improvements we are proposing within a specific area of the product. The desired outcome is to ensure it's as small as possible, maximizes our ability to iterate, and makes it easy to track overall progress on delivery, while providing meaningful value and avoiding an undue amount of "change fatigue" for our customers.

### Collaboration between backend and frontend

#### Using the ~"backend complete" label

The ~"backend complete" label is added to issues with multiple specializations (usually backend and
frontend) to indicate that the backend component is complete. Add this label when the backend work is
functionally complete, merged and verified but frontend, or other, work is ongoing.

### Picking something to work on

Use the [issues labeled `group::work items` in the current milestone](https://gitlab.com/groups/gitlab-org/-/issues/?label_name%5B%5D=group%3A%3Awork%20items&milestone_title=%23started) for this milestone's work, or the [full list](https://gitlab.com/groups/gitlab-org/-/issues/?label_name%5B%5D=group%3A%3Awork%20items) for everything. Filter by ~backend to see issues for backend engineers.

It's OK to not take the top item if you are not confident you can solve
it. Post in [#g_work_items](https://gitlab.slack.com/archives/g_work_items) if that's the case, as it probably
means the issue needs a better spec.

### High severity issues

{{% include "includes/engineering/plan/high-severity-items.md" %}}

### Working on unscheduled issues

We follow the [ownership mindset](/handbook/company/operating-principles/#ownership-mindset) operating principle: the people closest to the work make the decisions about it, and they own the result. We also measure ourselves by [customer outcomes](/handbook/company/operating-principles/#customer-outcomes), not by activity on our side.
If you see something important that is not scheduled, you can [request for it to be scheduled](/handbook/engineering/workflow/#requesting-something-to-be-scheduled)
or [work on a proposal yourself](/handbook/values/#iteration). Assign it to yourself and share it in [#g_work_items](https://gitlab.slack.com/archives/g_work_items).

## Useful links

- [Issues labeled `group::work items`](https://gitlab.com/groups/gitlab-org/-/issues/?label_name%5B%5D=group%3A%3Awork%20items)
- [Same list, current milestone](https://gitlab.com/groups/gitlab-org/-/issues/?label_name%5B%5D=group%3A%3Awork%20items&milestone_title=%23started)
- [Error budget dashboard](https://dashboards.gitlab.net/d/stage-groups-work_items/stage-groups-group-dashboard-plan-work-items)
- [Engineering Excellence dashboard for the Plan stage](https://gitlab-com.gitlab.io/eng-excellence/?view=ee&scope=stage%3Aplan) (internal)
- [#g_work_items](https://gitlab.slack.com/archives/g_work_items) and [#s_plan](https://gitlab.slack.com/archives/s_plan) in Slack
- [Current jobs](https://about.gitlab.com/jobs/)
